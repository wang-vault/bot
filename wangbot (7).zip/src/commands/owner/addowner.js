// ============================================================
//  .addowner  —  VERSI SELF-CONTAINED (tanpa proteksi isOwner)
//  Upload file INI SAJA ke: src/commands/owner/addowner.js
//  Cara pakai: DM bot lalu ketik  .addowner   (TANPA nomor)
//  => bot pakai JID kamu persis apa adanya => DIJAMIN cocok.
// ============================================================
module.exports = {
  name: 'addowner',
  aliases: ['setowner', 'claimowner', 'claim', 'jadikanowner'],
  category: 'owner',
  // isOwner sengaja DIMATIKAN supaya bisa daftar owner tanpa .env.
  desc: 'Daftar jadi owner. Ketik tanpa nomor = pakai JID kamu sendiri (paling pasti).',
  use: '[nomor]   <- kosongkan untuk pakai JID sendiri',
  run: async (m) => {
    let jid = ''
    if (m.mentionedJid && m.mentionedJid[0]) {
      jid = m.mentionedJid[0]
    } else if (m.quoted && m.quoted.sender) {
      jid = m.quoted.sender
    } else if (m.args && m.args.trim()) {
      // ada input nomor -> normalisasi
      let n = m.args.replace(/[^0-9]/g, '')
      if (n.startsWith('0')) n = '62' + n.slice(1)
      if (n) jid = n + '@s.whatsapp.net'
    } else {
      // TANPA argumen -> pakai JID pengirim persis apa adanya (DIJAMIN cocok)
      jid = m.sender
    }

    if (!jid) return m.reply('❌ Gagal ambil JID. Coba: .addowner 082189822272')

    const added = m.db.addOwner(jid)
    const note = jid === m.sender ? '\n📌 (Ini JID kamu persis yang dilihat bot, jadi pasti cocok.)' : ''
    if (added) {
      await m.reply(
        '✅ ' + jid + ' sekarang jadi *OWNER*.' + note + '\n\nKetik .id untuk cek.'
      )
    } else {
      await m.reply('ℹ️ ' + jid + ' sudah terdaftar owner. Ketik .id untuk cek.')
    }
  },
}
