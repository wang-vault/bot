const Panel = require('../../lib/panel')

module.exports = {
  name: 'servers',
  aliases: ['jumlahserver', 'serveraktif'],
  category: 'monitoring',
  desc: 'Jumlah server aktif & total resource terpakai.',
  run: async (m) => {
    const summary = await Panel.summary()
    if (!summary.configured) return m.reply('⚙️ Panel API belum dikonfigurasi.')
    if (summary.error) return m.reply('❌ ' + summary.error)

    let totalCpu = 0
    let totalRam = 0
    let totalDisk = 0
    for (const n of summary.nodes) {
      totalCpu += parseInt(String(n.cpu).replace('%', '')) || 0
      totalRam += parseInt(String(n.ram).replace(/\D/g, '')) || 0
      totalDisk += parseInt(String(n.disk).replace(/\D/g, '')) || 0
    }

    const t =
      '📦 *STATISTIK SERVER*\n\n' +
      `Total Node  : ${summary.totalNodes}\n` +
      `Server Aktif: ${summary.activeServers} / ${summary.totalServers}\n` +
      `Total CPU   : ${totalCpu}%\n` +
      `Total RAM   : ${totalRam} MB\n` +
      `Total Disk  : ${totalDisk} MB`
    await m.reply(t)
  },
}
